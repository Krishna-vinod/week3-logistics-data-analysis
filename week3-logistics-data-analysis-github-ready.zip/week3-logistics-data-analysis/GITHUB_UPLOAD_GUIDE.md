# GitHub Upload Guide

1. Create a public repository named `week3-logistics-data-analysis`.
2. Upload all files while preserving the folder structure.
3. Commit with: `Initial Week 3 logistics analysis`.
4. Verify README.md and the folders.
5. Your final link will be:
   `https://github.com/YOUR_USERNAME/week3-logistics-data-analysis`
